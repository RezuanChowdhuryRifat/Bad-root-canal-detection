
import os
filepath = "C:/Users/rezua/Documents/GitHub/yolov7/custom_dataset/labels/val/"


path = os.listdir(filepath)
for content in path:
  print(content)

def label_modifier (current,new,path,filepath):
 current = current
 new = new
 for content in path:
  with open(filepath + content, "r", encoding = "utf-8") as file:
    result = file.read()
  result = result.replace(current, new)
  with open(filepath + content, "w", encoding = "utf-8") as newfile:
    newfile.write(result)
label_modifier('1','0',path,filepath)
label_modifier('2','1',path,filepath)
label_modifier('3','2',path,filepath)
label_modifier('4','3',path,filepath)